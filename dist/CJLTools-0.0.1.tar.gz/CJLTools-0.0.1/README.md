# Some small tools

## Install using pip
``` python
pip install CJLTools
```

## Using
``` python
from CJLTools inport *
```
